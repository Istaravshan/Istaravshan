<?php
  $hostname = "localhost";
  $username = "v92366nc_222";
  $password = "Man1sur2001!";
  $dbname = "v92366nc_222";

  $conn = mysqli_connect($hostname, $username, $password, $dbname);
  if(!$conn){
    echo "Database connection error".mysqli_connect_error();
  }
?>
